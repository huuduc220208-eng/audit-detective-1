# Audit Detective Online

Game multiplayer realtime dùng Node.js, Express và Socket.IO.

## Chạy thử
Cần Node.js 18+:

```bash
npm install
npm start
```
Mở http://localhost:3000. Tạo phòng, gửi mã phòng cho đồng đội.

## Tính năng
- Phòng tối đa 24 người, mã phòng 5 ký tự.
- Chia đội A/B/C/D, nhiều thành viên cùng đội.
- Bốn bước: thu thập bằng chứng, phân tích rủi ro, kiểm tra & đối chiếu, kết luận & báo cáo.
- Trả lời realtime, điểm cá nhân và bảng xếp hạng đội.
- Nhân vật chibi CSS animation.

## Đưa lên mạng
Deploy project lên hosting hỗ trợ Node.js và WebSocket (Render, Railway hoặc VPS). Chia sẻ URL và mã phòng. Bản mẫu lưu phòng trong RAM; khi server khởi động lại, dữ liệu phòng bị xóa. Chưa có đăng nhập, lưu lịch sử hoặc chống gian lận nâng cao.
